from setuptools import setup, find_packages

setup(
    name="calulation_mine_library",  # Name of the library
    version="0.1",  # Version number
     packages=find_packages(),  
   
    url="https://github.com/VimalKS1/Python_projects",  
    
)
